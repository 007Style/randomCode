// Chilkat Java XMP Example Program
	
import com.chilkatsoft.CkXmp;
import com.chilkatsoft.CkXml;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

public class XmpInsert {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Insert XMP metadata into a JPG (or TIFF) that does not yet have embedded XMP.

  public static void main(String argv[]) 
  {
    CkXmp xmp = new CkXmp();
    xmp.UnlockComponent("anything for 30-day trial");
    
	// The first step is to create a new XMP document, which is nothing
	// more than XML.  The NewXmp method returns an XML document with
	// the standard XMP boilerplate.  
    CkXml xml = new CkXml();
	xmp.NewXmp(xml);
	
	// Add some properties...
	xmp.AddSimpleStr(xml,"Iptc4xmpCore:Chilkat","Blah blah");
	
	// If you wish to view the XML, save it to a file and review it
	// with a text editor:
	xml.SaveXml("output/newXmp.xml");
		
	// To add the XMP to the JPG (or TIFF), simply load the JPG,
	// append the XMP, and save:
	xmp.LoadAppFile("images/scream.jpg");
	xmp.Append(xml);
	xmp.SaveAppFile("output/screamOut.jpg");
	  
  }
}
