// Chilkat Java Example Program
	
import com.chilkatsoft.CkString;
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class EmailHtml2 {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Java example program to dynamically generate an HTML email 
  // with embedded images and CSS style sheet and send.  	 
  public static void main(String argv[]) 
  {
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, set username/password
    //mailman.put_SmtpUsername("myUsername");
    //mailman.put_SmtpPassword("myPassword");
    
    // Create a new email object.
    CkEmail email = new CkEmail();
    
    // Images that are embedded within an HTML email are reference by "CID" links.
    // For example, an HTML IMG tag has a CID URL for the SRC attribute:
    // <img src="CID:abc123">
    // When creating an HTML email with embedded images using Chilkat, you first add
    // each image to the email.  Embedded images (and style sheets) are considered
    // "related" items.  They are not attachments and are not listed as files attached
    // to an email because they are considered to be part of the HTML body.
    
    // This email will need 5 related items (4 images and 1 style sheet)
    CkString cid1 = new CkString();
    CkString cid2 = new CkString();
    CkString cid3 = new CkString();
    CkString cid4 = new CkString();
    CkString cid5 = new CkString();
    
	String css = "table#tscr {" +
"	border: 1px dashed;" +
"	margin: 8px;" +
"}" +
"table#tscr td {" +
"	font-family: Verdana;" +
"	font-size: 9pt;" +
"}";

	// If the file on disk could not be found, or there were file permission issues,
	// a false value is returned.  The CID is returned in the 2nd argument.
	// This example will not check the return values...
	boolean b1 = email.AddRelatedFile("images/dudeJava.gif",cid1);
	boolean b2 = email.AddRelatedFile("images/dudePython.gif",cid2);
	boolean b3 = email.AddRelatedFile("images/dudePerl.gif",cid3);
	boolean b4 = email.AddRelatedFile("images/dudeRuby.gif",cid4);
    
    // Our style sheet will be added from an in-memory string.
    // The 1st argument is the "name" within the related part assigned to 
    // the related part.  It should be any filename such that the file extension
    // indicates the content-type (i.e. .gif, .jpg, .css, etc.)  It is not
    // a file that exists on disk.  The charset indicates the charset to use
    // for the text within the email.  Java uses Unicode, so we may want to use
    // latin1 (i.e. iso-8859-1) which is a 1-byte/character encoding instead of Unicode.
    email.AddRelatedString("sample.css",css,"iso-8859-1",cid5);
    
    // Now that the CIDs are known, the HTML can be formed:
    String html = "<html>" +
"<head>" +
"<link rel=\"stylesheet\" type=\"text/css\" href=\"CID:" + cid5.getString() + "\" />" +
"</head>" +
"<body>" +
"<table id=\"tscr\" cellpadding=\"0\" cellspacing=\"10\">" +
"<tbody><tr> " +
"<td colspan=\"4\"><b>NEW:</b> Chilkat for Java and Scripting Languages</td>" +
"</tr><tr>" +
"<td><a href=\"http://www.chilkatsoft.com/java.asp\">Java</a><br><a href=\"http://www.chilkatsoft.com/java.asp\"><img src=\"CID:" + cid1.getString() + "\" border=\"0\"></a></td>" +
"<td><a href=\"http://www.chilkatsoft.com/perl.asp\">Perl</a><br><a href=\"http://www.chilkatsoft.com/perl.asp\"><img src=\"CID:" + cid3.getString() + "\" border=\"0\"></a></td>" +
"<td><a href=\"http://www.chilkatsoft.com/python.asp\">Python</a><br><a href=\"http://www.chilkatsoft.com/python.asp\"><img src=\"CID:" + cid2.getString() + "\" border=\"0\"></a></td>" +
"<td><a href=\"http://www.chilkatsoft.com/ruby.asp\">Ruby</a><br><a href=\"http://www.chilkatsoft.com/ruby.asp\"><img src=\"CID:" + cid4.getString() + "\" border=\"0\"></a></td>" +
"</tr>" +
"</tbody></table>" +
"</body>" +
"</html>";
	
	// Add the HTML body.
	email.SetHtmlBody(html);
	    
    // We still need a subject, and To/From
    email.put_Subject("Sending HTML e-mail from Java");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    // This line is not necessary.  It simply saves the email as a .eml 
    // allowing you to examine the MIME source of the email in any text editor.
    email.SaveEml("test.eml");
    
    // Now send the HTML e-mail...
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}

