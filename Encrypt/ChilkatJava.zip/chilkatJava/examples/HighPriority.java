// High-priority email in Java using Chilkat's Java Email library.
		
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class HighPriority {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
  	// Instantiate a mailman object for sending.
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, uncomment these lines:
    // mailman.put_SmtpUsername("your_login");
    // mailman.put_SmtpPassword("your_password");

    	    
    // New email object..
    CkEmail email = new CkEmail();
    email.put_Subject("Sending high-priority email from Java");
    email.put_Body("This email was sent from a Java program");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    
	// Setting the priority of an email is simply a matter
	// of setting the X-Priority header field.
	// Values of 1 through 5 are acceptable, with 1 being the
	// highest priority, 3 = normal, and 5 = lowest priority.
		
	// Set the email's priority to high:
	email.AddHeaderField("X-Priority","1");
    
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
