// Chilkat Java HTML-to-XML Example Program
	
import com.chilkatsoft.CkHtmlToXml;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

public class HtmlToXml {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Convert a .html file to a well-formed .xml

  public static void main(String argv[]) 
  {
    CkHtmlToXml htmlConv = new CkHtmlToXml();
    htmlConv.UnlockComponent("anything for 30-day trial");
    
	htmlConv.ConvertFile("exampleData/test1.html","output/test1.xml");
	htmlConv.ConvertFile("exampleData/test2.html","output/test2.xml");
	htmlConv.ConvertFile("exampleData/test3.html","output/test3.xml");
	
	
  }
}
