// Chilkat Java Example Program
	
import com.chilkatsoft.CkMht;
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class EmailHtml1 {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Send an HTML email using CkMht to help
  // A sample .html file with four images and a style sheet
  // has been pre-made for this example (testEmail.html).
  // The images are located in the "images" subdirectory,
  // and the CSS file is found in the "css" subdirectory.
  // The CkMht class can load the HTML file and return
  // a CkEmail object with all external (related) items 
  // embedded (i.e. style sheets and images).
  public static void main(String argv[]) 
  {
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, set username/password
    //mailman.put_SmtpUsername("myUsername");
    //mailman.put_SmtpPassword("myPassword");
    
    // Use MHT to load an HTML file and return an email object:
    CkMht mht = new CkMht();
    mht.UnlockComponent("anything for 30-day trial");
    
    CkEmail email = mht.GetEmail("testEmail.html");
    
    // We still need a subject, and To/From
    email.put_Subject("Sending HTML mail from Java");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    // Now send the HTML email...
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}

/* 
	The contents of the testEmail.html file are:
	
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/testEmail.css" />
</head>
<body>
<table id="tscr" cellpadding="0" cellspacing="10">
<tbody><tr> 
<td colspan="4"><b>NEW:</b> Chilkat for Java and Scripting Languages</td>
</tr><tr>
<td><a href="http://www.chilkatsoft.com/java.asp">Java</a><br><a href="http://www.chilkatsoft.com/java.asp"><img src="images/dudeJava.gif" border="0"></a></td>
<td><a href="http://www.chilkatsoft.com/perl.asp">Perl</a><br><a href="http://www.chilkatsoft.com/perl.asp"><img src="images/dudePerl.gif" border="0"></a></td>
<td><a href="http://www.chilkatsoft.com/python.asp">Python</a><br><a href="http://www.chilkatsoft.com/python.asp"><img src="images/dudePython.gif" border="0"></a></td>
<td><a href="http://www.chilkatsoft.com/ruby.asp">Ruby</a><br><a href="http://www.chilkatsoft.com/ruby.asp"><img src="images/dudeRuby.gif" border="0"></a></td>
</tr>
</tbody></table>
</body>
</html>
	
		*/