// Chilkat Java Example Program
	
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class SignedEmail {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Send a signed email using the sender's digital certificate.
  public static void main(String argv[]) 
  {
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, set username/password
    //mailman.put_SmtpUsername("myUsername");
    //mailman.put_SmtpPassword("myPassword");
    
    // Create a simple email
    CkEmail email = new CkEmail();
    email.put_Subject("Sending signed mail from Java");
    email.put_Body("This email was sent from a Java program");
    email.put_From("TagTooga <admin@tagtooga.com>");
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("Support","support@chilkatsoft.com");
    
    // There are a number of ways to send digitally signed email using Chilkat.
    // This example demonstrates the easiest (other examples will explore
    // some of the other possibilities).
    // To send a signed email, the digital certificate matching the sender's email
    // address (in the FROM header field) should have been previously be installed on your computer
    // with the private key.  
    // If not, you may install from a .pfx (or .p12) file.
    // Double-click on the .pfx to install.  Do not check the "Enable strong private key
    // protection" checkbox because if you do, programs that access the private key
    // will cause the operating system to display a pop-up warning dialog to 
    // notify the logged-in user of the private key access.  Otherwise, select all the
    // defaults and import the certificate.
    // 
    // IMPORTANT: The .pfx should be imported from the same logged-in account
    // under which the program will be running.  This is because private keys
    // are stored by Windows within the logged-on user's "protected store".
    //
    // Once the PFX is installed, the Chilkat component should be able to locate
    // the certificate for signing.  You only need to set the SendSigned property = true:
    email.put_SendSigned(true);
    
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
