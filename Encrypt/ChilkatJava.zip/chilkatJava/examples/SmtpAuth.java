// SMTP Authentication in Java using Chilkat's Java Email library.
		
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class SmtpAuth {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
  	// Instantiate a mailman object for sending.
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, uncomment these lines:
    // mailman.put_SmtpUsername("your_login");
    // mailman.put_SmtpPassword("your_password");

	// Your SMTP server may or may not require authentication.  It often depends
	// upon the location where the SMTP client is making the connection.  If the
	// SMTP server is behind a firewall, it is often administered such that clients
	// connecting from the same side of the firewall (i.e. within the network) can
	// send email without authentication.  However, connections originating from
	// outside the firewall DO require authentication.  This is quite often the
	// case with cable modem and DSL ISP's.  
	// If authentication is required, different SMTP servers support different authentication
	// methods, some of which are more secure than others.  In the least secure scenario,
	// your login/password is transmitted in clear-text (i.e. unencrypted) over the TCP/IP
	// connection to the SMTP server.  This is with the "LOGIN" method.
	// The "PLAIN" SMTP authentication method is effectively no better because the information
	// is simply Base64 encoded.  The CRAM-MD5 and NTLM methods are secure because the
	// login/password is sent encrypted.  However, if your connection to the SMTP server is
	// SSL, or if you are using the STARTTLS option, it doesn't matter if the authentication
	// method is LOGIN or PLAIN because the TCP/IP connection is SSL anyway.
	// By default, Chilkat will choose the most secure authentication method available
	// (as announced by the SMTP server during the initial "hello" handshake).
	// If for some reason there is a problem, or if you desire less-secure authentication,
	// you may explicitly set the SmtpAuthMethod property to: "LOGIN", "PLAIN", "CRAM-MD5", or "NTLM".
	mailman.put_SmtpAuthMethod("LOGIN");
    	    
    // New email object..
    CkEmail email = new CkEmail();
    email.put_Subject("Sending email from Java");
    email.put_Body("This email was sent from a Java program");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
