// String-to-String HTML to XML conversion.
	
import com.chilkatsoft.CkHtmlToXml;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

public class HtmlParse {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Convert an HTML string into an XML string.  Demonstrate how text formatting
// tags can be optionally dropped.  Text formatting tags are: 
// b, font, i, u, br, center, em, strong, big, tt, s, small, strike, sub, and sup.

  public static void main(String argv[]) 
  {
    CkHtmlToXml htmlConv = new CkHtmlToXml();
    htmlConv.UnlockComponent("anything for 30-day trial");
    
	String html = "<html><body>This <b>is</b> a <i>test</i></body></html>";
	
	// To convert, set the HTML and get the XML:
	htmlConv.put_Html(html);
	String xml = htmlConv.xml();
	
	System.out.println(xml);
	
	/*
		The output is this:
		
		<?xml version="1.0" encoding="utf-8" ?>

		<root>
		    <html>
		        <body>
		            <text>This  is a  test</text>
		        </body>
		    </html>
		</root>
		
		*/
			
	// What happened to the <b> and <i> tags???
	// By default, text formatting tags are dropped.
	// If we call UndropTextFormattingTags, the tags will remain:
	htmlConv.UndropTextFormattingTags();
	
	xml = htmlConv.xml();
	
	System.out.println(xml);
	
	/*
		We now get this:
		
		<?xml version="1.0" encoding="utf-8" ?>

		<root>
		    <html>
		        <body>
		            <text>This </text>
		            <b>
		                <text>is</text>
		            </b>
		            <text>a </text>
		            <i>
		                <text>test</text>
		            </i>
		        </body>
		    </html>
		</root>
			
	*/
  }
}
