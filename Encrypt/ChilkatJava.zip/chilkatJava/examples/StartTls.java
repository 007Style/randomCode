// Java program to send email over a secure channel using STARTTLS
	
// Connects to an SMTP server on the standard non-secure
// port 25 and issues a STARTTLS command to convert the connection
// to a secure SSL/TLS channel.

// One additional line of code is required to do this:
// you simply need to tell the mailman that you want STARTTLS
// by setting the StartTLS property = true.
	
// Note: When sending email using STARTTLS, *everything* is protected.
// If authentication is required, your login/password is sent securely.  
// The entire email, including attachments, is sent over SSL.
	
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class StartTls {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
  	// Instantiate a mailman object for sending.
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
	// Use STARTTLS
	mailman.put_StartTLS(true);

    // If your SMTP server requires a login, set login/password
    // mailman.put_SmtpUsername("***");
    // mailman.put_SmtpPassword("***");
    
    // New email object..
    CkEmail email = new CkEmail();
    email.put_Subject("Sending mail w/ STARTTLS from Java");
    email.put_Body("This mail message was sent from Java on a secure connection");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    
    // Add "TO" recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
