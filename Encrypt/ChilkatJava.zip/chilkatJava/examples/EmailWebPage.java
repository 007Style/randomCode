// Chilkat Java Example Program
	
import com.chilkatsoft.CkMht;
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class EmailWebPage {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Downloads a web page and all embedded images and CSS style
  // sheets into a CkEmail object.
  // The web page converted to email is: 
  // http://www.chilkatsoft.com/testEmail/testEmail.html
  public static void main(String argv[]) 
  {
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, set username/password
    //mailman.put_SmtpUsername("myUsername");
    //mailman.put_SmtpPassword("myPassword");
    
    // Use MHT to load a web page and return an email object:
    CkMht mht = new CkMht();
    mht.UnlockComponent("anything for 30-day trial");
    
    CkEmail email = mht.GetEmail("http://www.chilkatsoft.com/testEmail/testEmail.html");
    
    // We still need a subject, and To/From
    email.put_Subject("Sending HTML e-mail from Java");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    // Now send the HTML e-mail...
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}

