// Chilkat Java Example Program
	
import com.chilkatsoft.CkZip;

public class ZipExample1 {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Simple example showing how to zip a directory tree.
  public static void main(String argv[]) 
  {
    CkZip zip = new CkZip();
    zip.UnlockComponent("anything for 30-day trial");
    
    zip.NewZip("exampleData.zip");
    zip.AppendFiles("exampleData/*",true);
    zip.WriteZip();
    
  }
}
