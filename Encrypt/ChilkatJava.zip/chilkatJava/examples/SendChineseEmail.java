// Java program to send Chinese email
	
// This source file contains Chinese characters and is therefore
// saved using the utf-8 encoding.

// When you compile this program with the command javac ***.java, 
// the compiler does not know the encoding of the source file and uses your
// computer's default encoding. You must tell javac which encoding to 
// use explicitly. Use the -encoding option to do this: 
// javac -encoding utf8 ***.java .
	
// Also, do not emit the 3-byte BOM (byte order mark) signature at the 
// beginning of the file.  The BOM bytes will cause  javac compiler to fail.
// Files containing the 3-byte utf-8 BOM will begin with 0xEF 0xBB 0xBF
	
	
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class SendChineseEmail {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Simple example showing how to send Chinese mail in Java
  public static void main(String argv[]) 
  {
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, set username/password
    //mailman.put_SmtpUsername("myUsername");
    //mailman.put_SmtpPassword("myPassword");
    
    // Create a simple email using Chinese characters in subject, body, ...
    CkEmail email = new CkEmail();
    email.put_Subject("我能吞下玻璃而不伤身体");
    email.put_Body("我能吞下玻璃而不伤身体");
    email.put_From("我能 <support@chilkatsoft.com>");
    // Add a few recipients
    email.AddTo("下玻","matt@chilkatsoft.com");
    email.AddTo("身体","admin@tagtooga.com");
    
    // Chilkat automatically recognizes the Chinese characters and chooses
    // a typical charset for Chinese email: GB2312.
    // Had the email contained characters not representable in GB2312 (such as Hebrew 
    // characters) the component would have automatically chosen utf-8 as the encoding.

    // The charset used throughout the entire email can be explicitly changed by setting
    // the Charset property:
    // email.put_Charset("utf-8");

	// Send the email...
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
