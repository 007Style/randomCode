// Chilkat Java XMP Example Program
	
import com.chilkatsoft.CkXmp;
import com.chilkatsoft.CkXml;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;
import com.chilkatsoft.CkStringArray;

public class XmpAddArray {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Insert an array property into an XMP document (embedded within a JPG or TIFF)

  public static void main(String argv[]) 
  {
    CkXmp xmp = new CkXmp();
    xmp.UnlockComponent("anything for 30-day trial");
    
	// Open a JPG containing XMP embedded metadata.
	boolean success = xmp.LoadAppFile("images/IndependantPhotographer-Example.jpg");
	if (!success)
	{
		xmp.SaveLastError("output/xmpError.xml");
		return;
	}
	
	// How many embedded XMP documents?
	int n = xmp.get_NumEmbedded();
	
	// Get the 1st XMP.
	CkXml xml = xmp.GetEmbedded(0);
	
	// Create a new array
    CkStringArray sa = new CkStringArray();

	sa.Append("chilkat");
	sa.Append("XMP");
	sa.Append("Java");
	sa.Append("component");
	
	// AddArray inserts an array property into the XMP document.
	// If a property with the same name already exists, it is 
	// automatically replaced.
	// The 2nd argument can be "bag", "alt", or "seq"
	xmp.AddArray(xml,"bag","Iptc4xmpCore:Chilkat",sa);
	
	// Save the JPG.
	xmp.SaveAppFile("output/modified.jpg");
	
  
  }
}
