// Chilkat Java Example Program:
// Download a web page and save as a .mht web archive.
	
import com.chilkatsoft.CkMht;

public class WebPageToMht {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
    // Create a MHT object...
    CkMht mht = new CkMht();
    mht.UnlockComponent("anything for 30-day trial");
    
    boolean success = mht.GetAndSaveMHT("http://www.steve.com","output/steve.mht");
    if (!success)
    {
    	mht.SaveLastError("lastError.txt");	
    }
    
  }
}

