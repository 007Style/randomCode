// Chilkat Java Example Program
	
// When you compile this program with the command javac Utf8Test.java, 
// the compiler does not know the encoding of the source file. Therefore it uses your
// computer's default encoding. You should tell javac which encoding to 
// use explicitly. Use the -encoding option to do this: 
// javac -encoding utf8 Utf8Test.java .
	
// Also, do not emit the 3-byte BOM (byte order mark) signature at the 
// beginning of the file.  The BOM bytes will cause  javac compiler to fail.
// Files containing the 3-byte utf-8 BOM will begin with 0xEF 0xBB 0xBF
	
import com.chilkatsoft.CkString;

public class Utf8Test {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
  	// Because this source code is saved using the utf-8 character
  	// encoding, we can write literal strings in any language.
  	// This is a Japanese string:
  	String test = "愛知県新城市の";
  	
  	// Chilkat provides a CkString class that is used with 
  	// many of the other Chilkat classes.
    CkString str = new CkString();
    // Java strings may be appended.
    str.append(test);
    
    // Save the string in various encodings.    
    str.saveToFile("utf8.txt","utf-8");
    str.saveToFile("shiftJis.txt","shift_JIS");
    str.saveToFile("iso-2022-jp.txt","iso-2022-jp");
    str.saveToFile("euc-jp.txt","euc-jp");
    
  }
}
