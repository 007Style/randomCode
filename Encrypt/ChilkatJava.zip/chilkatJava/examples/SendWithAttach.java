// Chilkat Java Example Program
	
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;
import com.chilkatsoft.CkString;

public class SendWithAttach {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Sending email with attachments in Java.
  public static void main(String argv[]) 
  {
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, set username/password
    //mailman.put_SmtpUsername("myUsername");
    //mailman.put_SmtpPassword("myPassword");
    
    // Create a simple email
    CkEmail email = new CkEmail();
    email.put_Subject("Sending mail from Java");
    email.put_Body("This email was sent from a Java program");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    // Attachments can be added from files or in-memory data.
    // Returns true if the file was added successfully.  The content-type
    // is returned in the 2nd argument.  This is for the benefit of programs
    // that may need it (for whatever reason), but most users do not.
    CkString contentType = new CkString();
    boolean b = email.AddFileAttachment("exampleData/hamlet.xml",contentType);
    
    // You may add a text file attachment directly from a string in memory.
    // AddStringAttachment2 allows for the charset encoding to be directly specified.
    // AddStringAttachment automatically uses the utf-8 encoding for text file attachments.
    email.AddStringAttachment("test1.txt","This string is the content of test1.txt");
    email.AddStringAttachment2("test2.txt","This string is the content of test2.txt","iso-8859-1");
    	
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
