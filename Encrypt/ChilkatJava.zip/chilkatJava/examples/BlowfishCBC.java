// Chilkat Java Example Program
	
import com.chilkatsoft.CkCrypt2;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

public class BlowfishCBC {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Java Blowfish CBC Encryption to match published test vector
// at http://www.schneier.com/code/vectors.txt
// Reproduced here:
// chaining mode test data
// key[16]  (0123456789ABCDEFF0E1D2C3B4A59687
// IV [8](FEDCBA9876543210
// data[29] ("7654321 Now is the time for " (includes trailing '\0')
// vdata[29] (37363534333231204E6F77206973207468652074696D6520666F722000
// cipher[32]= 6B77B4D63006DEE605B156E27403979358DEB9E7154616D959F1652BD5FF92CC

  public static void main(String argv[]) 
  {
    CkCrypt2 crypt = new CkCrypt2();
    crypt.UnlockComponent("anything for 30-day trial");
    
	// Set the CryptAlgorithm to "blowfish2".  Chilkat's original implementation
	// of Blowfish ("blowfish") did not include CBC and returned encrypted data
	// 4321 byte-swapped.  For backward compatibility, an additional CryptAlgorithm
	// keyword ("blowfish2") was added to indicate the new Blowfish implementation.
	crypt.put_CryptAlgorithm("blowfish2");
	    
	crypt.put_CipherMode("cbc");
	crypt.put_KeyLength(128);
	    
	// Padding Schemes:
	// 0((RFC2630) Each padding byte is the pad count (16 extra added if size is already a multiple of 16)
	// 1(Random bytes except the last is the pad count (16 extra added if size is already multiple of 16)
	// 2(Pad with random data. (If already a multiple of 16, no padding is added).
	// 3(Pad with NULLs. (If already a multiple of 16, no padding is added).
	// 4(Pad with SPACE chars(0x20). (If already a multiple of 16, no padding is added).
	    
	// To match the test vector output, we need to pad with NULL bytes.
	crypt.put_PaddingScheme(3);
	    
	// Set the IV property via an encoded string.
	crypt.SetEncodedIV("FEDCBA9876543210", "hex");
	    
	// Set the SecretKey property via an encoded string.
	crypt.SetEncodedKey("0123456789ABCDEFF0E1D2C3B4A59687", "hex");
	    
	// Get the unencrypted data.
	CkByteData unencryptedData = new CkByteData();
	crypt.Decode("37363534333231204E6F77206973207468652074696D6520666F722000", "hex",unencryptedData);
	    
	// Now encrypted it using the settings required to match the Blowfish test vector results.
	crypt.put_EncodingMode("hex");
	CkString encryptedHexString = new CkString();
	crypt.EncryptBytesENC(unencryptedData,encryptedHexString);
	    
	// Displays: 6B77B4D63006DEE605B156E27403979358DEB9E7154616D959F1652BD5FF92CC
	System.out.println(encryptedHexString.getString());
   
  }
}
