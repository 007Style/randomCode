// Chilkat Java Example Program:
// Save an in-memory HTML string to a .mht web archive.
	
import com.chilkatsoft.CkMht;
import com.chilkatsoft.CkString;

public class HtmlToMht {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
    // Create a MHT object...
    CkMht mht = new CkMht();
    mht.UnlockComponent("anything for 30-day trial");
    
    String html = "<html><body><img src=\"http://www.chilkatsoft.com/images/dude.gif\"><br>Chilkat Software Inc</body></html>";
    CkString strMht = new CkString();
    boolean success = mht.HtmlToMHT(html,strMht);
    if (!success)
    {
    	mht.SaveLastError("lastError.txt");	
    }
    else
    {
    	// Save the string to a file...
    	strMht.saveToFile("output/dude.mht","windows-1252");
    	
    	// To access the MHT string, do this:
    	String mhtString = strMht.getString();
    }
    
  }
}

