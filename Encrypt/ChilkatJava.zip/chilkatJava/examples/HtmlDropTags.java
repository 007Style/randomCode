// Drop specific HTML tags during the HTML-to-XML conversion process.
	
import com.chilkatsoft.CkHtmlToXml;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

public class HtmlDropTags {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Demonstrates how to drop specific tags during the HTML-to-XML conversion.

  public static void main(String argv[]) 
  {
    CkHtmlToXml htmlConv = new CkHtmlToXml();
    htmlConv.UnlockComponent("anything for 30-day trial");
    
	String html = "<html><body><span>This <b>is</b> a <i>test</i><hr></span></body></html>";
	
	// First, call UndropTextFormattingTags to prevent the text formatting tags
	// from being dropped by default.
	htmlConv.UndropTextFormattingTags();

	// We'll want to drop <hr>, <i>, and <span> tags:
	htmlConv.DropTagType("hr");
	htmlConv.DropTagType("i");
	htmlConv.DropTagType("span");
	
	// To convert, set the HTML and get the XML:
	htmlConv.put_Html(html);
	String xml = htmlConv.xml();
	
	System.out.println(xml);
	
	/*
		The output is this:
		
		<?xml version="1.0" encoding="utf-8" ?>

		<root>
		    <html>
		        <body>
		            <text>This </text>
		            <b>
		                <text>is</text>
		            </b>
		            <text>a  test</text>
		        </body>
		    </html>
		</root>	
				
		*/
			
  }
}
