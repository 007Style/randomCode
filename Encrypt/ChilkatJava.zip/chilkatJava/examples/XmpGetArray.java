// Chilkat Java XMP Example Program
	
import com.chilkatsoft.CkXmp;
import com.chilkatsoft.CkXml;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;
import com.chilkatsoft.CkStringArray;

public class XmpGetArray {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Retrieve the contents of an XMP array property and iterate over the values.

  public static void main(String argv[]) 
  {
    CkXmp xmp = new CkXmp();
    xmp.UnlockComponent("anything for 30-day trial");
    
	// Open a JPG containing XMP embedded metadata.
	boolean success = xmp.LoadAppFile("images/IndependantPhotographer-Example.jpg");
	if (!success)
	{
		xmp.SaveLastError("output/xmpError.xml");
		return;
	}
	
	// How many embedded XMP documents?
	int n = xmp.get_NumEmbedded();
	
	// Get the 1st XMP.
	CkXml xml = xmp.GetEmbedded(0);
	
	// Get an array property.
    CkStringArray sa = new CkStringArray();
	xmp.GetArray(xml,"dc:subject",sa);
	
	// Print the array values
	n = sa.get_Count();
	int i;
	for (i=0; i<n; i++)
	{
		System.out.println(sa.strAt(i));
	}
	
	// Save the strings to a file, one per line...
	sa.SaveToFile("output/subjects.txt");
	
  
  }
}
