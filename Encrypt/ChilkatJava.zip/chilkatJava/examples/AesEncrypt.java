// Chilkat Java AES Encryption Example Program
	
import com.chilkatsoft.CkCrypt2;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

public class AesEncrypt {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// AES Encrypt / Decrypt a String.

  public static void main(String argv[]) 
  {
    CkCrypt2 crypt = new CkCrypt2();
    crypt.UnlockComponent("anything for 30-day trial");
    
	crypt.put_CryptAlgorithm("aes");
	crypt.put_CipherMode("cbc");
	crypt.put_KeyLength(128);
	crypt.put_EncodingMode("base64");
	
	CkByteData secretKey = new CkByteData();
	crypt.GenerateSecretKey("myPassword",secretKey);
	crypt.put_SecretKey(secretKey);
	    
	CkString encrypted = new CkString();
    crypt.EncryptStringENC("This string is to be encrypted",encrypted);
	    
	// Displays: cZLpHHyRILPmgdLF0ZauLK/2++YO/uBfPPkQl/WS9u0=
	System.out.println(encrypted.getString());
	
	CkString decrypted = new CkString();
    crypt.DecryptStringENC(encrypted.getString(),decrypted);
    
 	// Displays: This string is to be encrypted
	System.out.println(decrypted.getString());
  
  }
}
