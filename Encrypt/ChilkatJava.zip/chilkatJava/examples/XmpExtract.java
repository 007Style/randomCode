// Chilkat Java XMP Example Program
	
import com.chilkatsoft.CkXmp;
import com.chilkatsoft.CkXml;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

public class XmpExtract {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Extract XMP metadata from a JPG

  public static void main(String argv[]) 
  {
    CkXmp xmp = new CkXmp();
    xmp.UnlockComponent("anything for 30-day trial");
    
	// Open a JPG containing XMP embedded metadata.
	boolean success = xmp.LoadAppFile("images/IndependantPhotographer-Example.jpg");
	if (!success)
	{
		xmp.SaveLastError("output/xmpError.xml");
		return;
	}
	
	// How many embedded XMP documents?
	int n = xmp.get_NumEmbedded();
	
	// Get the 1st XMP.
	CkXml xml = xmp.GetEmbedded(0);
	
	// Save it to an XML file.
	xml.SaveXml("output/xmpMetadata.xml");
  
  }
}
