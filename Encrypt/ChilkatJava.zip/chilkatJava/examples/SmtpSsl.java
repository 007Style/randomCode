// Chilkat Java Example Program for Sending Email over SSL
	
// Connects to an SMTP server via SSL and sends mail.
// The default non-secure port for SMTP servers is 25.
// Usually, the SMTP SSL port is 465.  To send e-mail over
// SSL, it's as simple as setting two properties prior to sending:
	
// 1) Set the SmtpSsl property = true to indicate that you want SSL.
// 2) Set the SmtpPort property = 465

// Note: When sending email over an SSL connection, *everything* is protected.
// If authentication is required, your login/password is sent securely.  
// The entire email, including attachments, is sent over SSL.

	
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class SmtpSsl {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
  	// Instantiate a mailman object for sending.
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
	// Set SSL properties:
	mailman.put_SmtpPort(465);
	mailman.put_SmtpSsl(true);

    // If your SMTP server requires a login, set username/password
    mailman.put_SmtpUsername("***");
    mailman.put_SmtpPassword("***");
    
    // New email object..
    CkEmail email = new CkEmail();
    email.put_Subject("Sending mail over SSL from Java");
    email.put_Body("This email was sent from a Java program on a secure connection");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
