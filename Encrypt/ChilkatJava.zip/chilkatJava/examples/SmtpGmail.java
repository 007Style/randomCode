// Using GMail as your SMTP Server
	
// Demonstrates how to send email using the GMail SMTP Server 
// (smtp.gmail.com)
	
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class SmtpGmail {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
  	// Instantiate a mailman object for sending.
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.gmail.com");
    
    // GMail requires a login/password to send mail.
    mailman.put_SmtpUsername("your_email@gmail.com");
    mailman.put_SmtpPassword("your_password");
    
    // The default SMTP port is 25.  When using it, GMail requires STARTTLS.
    mailman.put_StartTLS(true);
    
    // Alternatively, you may comment-out the STARTTLS line and instead use SSL
    // on port 465 by commenting-in these 2 lines:
	//mailman.put_SmtpPort(465);
	//mailman.put_SmtpSsl(true);
	
	// If you are connected to a network that blocks outbound port 25 connections,
	// use GMail's alternative port 587.  You'll need STARTTLS, so uncomment the 
	// STARTTLS line and make sure the two lines for SMTP SSL are commented out.
	//mailman.put_SmtpPort(587);
    
    // New email object..
    CkEmail email = new CkEmail();
    email.put_Subject("Sending email using GMail SMTP");
    email.put_Body("This email was sent from the GMail SMTP Server");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
