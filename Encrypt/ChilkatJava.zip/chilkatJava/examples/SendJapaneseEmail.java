// Java program to send Japanese email
	
// This source file contains Japanese characters and is therefore
// saved using the utf-8 encoding.

// When you compile this program with the command javac ***.java, 
// the compiler does not know the encoding of the source file. Therefore it uses your
// computer's default encoding. You must tell javac which encoding to 
// use explicitly. Use the -encoding option to do this: 
// javac -encoding utf8 ***.java .
	
// Also, do not emit the 3-byte BOM (byte order mark) signature at the 
// beginning of the file.  The BOM bytes will cause  javac compiler to fail.
// Files containing the 3-byte utf-8 BOM will begin with 0xEF 0xBB 0xBF
	
	
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class SendJapaneseEmail {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Simple example showing how to send Japanese mail in Java
  public static void main(String argv[]) 
  {
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, set username/password
    //mailman.put_SmtpUsername("myUsername");
    //mailman.put_SmtpPassword("myPassword");
    
    // Create a simple email using Japanese characters in subject, body, ...
    CkEmail email = new CkEmail();
    email.put_Subject("私はガラスを食べられます。");
    email.put_Body("私はガラスを食べられます。それは私を傷つけません。");
    email.put_From("を傷つけ <support@chilkatsoft.com>");
    // Add a few recipients
    email.AddTo("れます","matt@chilkatsoft.com");
    email.AddTo("ラスを","admin@tagtooga.com");
    
    // Chilkat automatically recognizes the Japanese characters and chooses
    // a typical charset for Japanese email: Shift_JIS.
    // Had the email contained characters not representable in Shift_JIS (such as Chinese 
    // characters) the component would have automatically chosen utf-8 as the encoding.

    // The charset used throughout the entire email can be explicitly changed by setting
    // the Charset property:
    email.put_Charset("iso-2022-jp");

	// Send the email...
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
