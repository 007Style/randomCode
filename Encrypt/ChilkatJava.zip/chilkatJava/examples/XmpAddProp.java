// Chilkat Java XMP Example Program
	
import com.chilkatsoft.CkXmp;
import com.chilkatsoft.CkXml;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

public class XmpAddProp {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
  
// Add new properties to XMP metadata in a JPG, or update existing property values.

  public static void main(String argv[]) 
  {
    CkXmp xmp = new CkXmp();
    xmp.UnlockComponent("anything for 30-day trial");
    
	// Open a JPG containing XMP embedded metadata.
	boolean success = xmp.LoadAppFile("images/IndependantPhotographer-Example.jpg");
	if (!success)
	{
		xmp.SaveLastError("output/xmpError.xml");
		return;
	}
	
	// How many embedded XMP documents?
	int n = xmp.get_NumEmbedded();
	
	// Get the 1st XMP.
	CkXml xml = xmp.GetEmbedded(0);
	
	// Add or replace some simple string properties.
	// If a property already exists, it is replaced.
	xmp.AddSimpleStr(xml,"Iptc4xmpCore:Chilkat","Blah blah");
	xmp.AddSimpleStr(xml,"xmpPLUS:Chilkat","Blah2 blah2");
	xmp.AddSimpleStr(xml,"pdf:Chilkat","Blah3 blah3");
	
	// If you have a custom namespace, add a namespace mapping first...
	xmp.AddNsMapping("chilkat","http://www.chilkatsoft.com/");
	xmp.AddSimpleStr(xml,"chilkat:Testing","Test 123 ABC");
	
	// Save the XMP document (as XML) after adding the properties, for the purpose
	// of visually reviewing the changes.
	xml.SaveXml("output/updatedXmp.xml");
	
	// Re-write the JPG with the new properties added.
	xmp.SaveAppFile("output/updated.jpg");
	  
  }
}
