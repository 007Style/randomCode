// Send email requesting a return-receipt in Java using Chilkat's Java Email library.
		
import com.chilkatsoft.CkMailMan;
import com.chilkatsoft.CkEmail;

public class ReturnReceipt {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  public static void main(String argv[]) 
  {
  	// Instantiate a mailman object for sending.
    CkMailMan mailman = new CkMailMan();
    mailman.UnlockComponent("anything for 30-day trial");
    
    // Set your SMTP server's hostname
    mailman.put_SmtpHost("smtp.comcast.net");
    
    // If your SMTP server requires a login, uncomment these lines:
    // mailman.put_SmtpUsername("your_login");
    // mailman.put_SmtpPassword("your_password");

    	    
    // New email object..
    CkEmail email = new CkEmail();
    email.put_Subject("Sending email from Java with return-receipt requested");
    email.put_Body("This email was sent from a Java program");
    email.put_From("Chilkat Support <support@chilkatsoft.com>");
    
	// The disposition-notification-to email header field
	// is what should be set to requeset a return-receipt.
	// Information about numerous email header fields can be found
	// at this URL: http://chilkatsoft.com/braindump/email_headers.html
	// The Chilkat email component uses a ReturnReceipt property, which
	// if set to true causes the disposition-notification-to header
	// to be added to an email.
	email.put_ReturnReceipt(true);

	// An alternative way of doing the same thing is to do this:
	// email.AddHeaderField("Disposition-Notification-To","<support@chilkatsoft.com>");

    
    // Add a few recipients
    email.AddTo("Matt","matt@chilkatsoft.com");
    email.AddTo("TagTooga","admin@tagtooga.com");
    
    boolean success = mailman.SendEmail(email);
    if (!success)
    {
    	mailman.SaveLastError("lastError.txt");	
    }
    
  }
}
