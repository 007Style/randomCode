
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.io.*;

import com.chilkatsoft.CkCrypt2;
import com.chilkatsoft.CkByteData;
import com.chilkatsoft.CkString;

class AesMatchJce 
{
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }
	
 	public static String toHex (byte buf[]) {
 		
      StringBuffer strbuf = new StringBuffer(buf.length * 2);
      int i;

      for (i = 0; i < buf.length; i++) {
       if (((int) buf[i] & 0xff) < 0x10)
	    strbuf.append("0");

       strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
      }

      return strbuf.toString();
     }
     	
	public static void main(String args[]) throws Exception
	{
        // In Java, bytes are signed and range from -128 to 127
        // A value of -128 = 0x80.
        byte[] raw = { -128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        
        byte[] inBytes = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		byte[] encrypted = cipher.doFinal(inBytes);
     
     	System.out.println("Java:");
        System.out.println(toHex(encrypted));
		

	// --------------------------------------------
   	// Now do the same with Chilkat
	// --------------------------------------------

    CkCrypt2 crypt = new CkCrypt2();
    crypt.UnlockComponent("Anything for 30-day trial.");
    
	crypt.put_CryptAlgorithm("aes");
	crypt.put_CipherMode("ecb");
	crypt.put_KeyLength(128);
	crypt.put_EncodingMode("hex");
	crypt.put_Charset("windows-1252");
	
	crypt.SetEncodedKey("80000000000000000000000000000000","hex");
	
	CkByteData inData = new CkByteData();
	inData.appendEncoded("00000000000000000000000000000000","hex");
	    
	CkString encryptedStr = new CkString();
	crypt.EncryptBytesENC(inData,encryptedStr);
	
	// The result is correct: 0EDD33D3C621E546455BD8BA1418BEC8...
	// This is the result as specified by the NIST test vector...
	System.out.println("Chilkat:");    
	System.out.println(encryptedStr.getString());
        
	}




}