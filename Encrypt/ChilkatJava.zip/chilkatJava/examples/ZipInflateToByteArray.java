// Chilkat Java Example Program
	
import com.chilkatsoft.CkZip;
import com.chilkatsoft.CkZipEntry;
import com.chilkatsoft.CkByteData;

public class ZipInflateToByteArray {
	
  static {
    try {
        System.loadLibrary("chilkat");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Native code library failed to load.\n" + e);
      System.exit(1);
    }
  }

  // Simple example showing how to zip a directory tree.
  public static void main(String argv[]) 
  {
    CkZip zip = new CkZip();
    zip.UnlockComponent("anything for 30-day trial");

    boolean success;
    zip.NewZip("output/exampleData.zip");
    success = zip.AppendFiles("exampleData/*",true);
    if (!success) {
    	System.out.println(zip.lastErrorText());
    	return;
    }
    success = zip.WriteZipAndClose();
    if (!success) {
    	System.out.println(zip.lastErrorText());
    	return;
    }
    
    CkZip zip2 = new CkZip();
    success = zip2.OpenZip("output/exampleData.zip");
    if (!success) {
    	System.out.println(zip2.lastErrorText());
    	return;
    }
    
    CkZipEntry entry = zip2.FirstMatchingEntry("*/dude.gif");
    if (entry != null) {
    	CkByteData uncompressedData = new CkByteData();
    	success = entry.Inflate(uncompressedData);
	    if (!success) {
	    	System.out.println(entry.lastErrorText());
	    	return;
	    }
	    // Get the bytes...
	    byte[] fileData = uncompressedData.toByteArray();
    	System.out.println(fileData[0]);
    	System.out.println(fileData[1]);
    	System.out.println(fileData[2]);
    	System.out.println(fileData[3]);
    } else {
    	System.out.println("Entry not found!");
    	return;
    }
  }
}
